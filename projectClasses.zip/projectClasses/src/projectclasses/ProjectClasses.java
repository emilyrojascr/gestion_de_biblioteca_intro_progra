/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projectclasses;

/**
 *
 * @author eduar
 */
public class ProjectClasses {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
}