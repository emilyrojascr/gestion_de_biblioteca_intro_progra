/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projectclasses;

/**
 *
 * @author eduar
 */
public class ProjectClasses {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    //clase de Socio y sus atributos
    public class Socio {
    private String idSocio;
    private String nombreCompleto;
    private String fechaRegistro;
    private EstadoSocio estadoSocio;
    private double multasAcumuladas;
    private int cantidadLibrosPrestadosActual;

    
    //getters de la clase Socio
    
    public String getIdSocio() {
        return idSocio;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public String getFechaRegistro() {
        return fechaRegistro;
    }

    public EstadoSocio getEstadoSocio() {
        return estadoSocio;
    }

    public double getMultasAcumuladas() {
        return multasAcumuladas;
    }

    public int getCantidadLibrosPrestadosActual() {
        return cantidadLibrosPrestadosActual;
    }

    
    //setters de la clase Socio
    
    public void setIdSocio(String idSocio) {
        this.idSocio = idSocio;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public void setFechaRegistro(String fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public void setEstadoSocio(EstadoSocio estadoSocio) {
        this.estadoSocio = estadoSocio;
    }

    public void setMultasAcumuladas(double multasAcumuladas) {
        this.multasAcumuladas = multasAcumuladas;
    }

    public void setCantidadLibrosPrestadosActual(int cantidadLibrosPrestadosActual) {
        this.cantidadLibrosPrestadosActual = cantidadLibrosPrestadosActual;
    }
}

//enum para el estado del socio

enum EstadoSocio {
    ACTIVO,
    INACTIVO,
    SUSPENDIDO
}


//clase Libro y sus atributos

public class Libro {
    private String isbn;
    private String titulo;
    private String autor;
    private Genero genero;
    private String editorial;
    private int anioPublicacion;
    private EstadoLibro estadoLibro;
    private int vecesPrestado;

    
    
    //getters para la clase Libro
    
    public String getIsbn() {
        return isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public Genero getGenero() {
        return genero;
    }

    public String getEditorial() {
        return editorial;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public EstadoLibro getEstadoLibro() {
        return estadoLibro;
    }

    public int getVecesPrestado() {
        return vecesPrestado;
    }

    
    
    //setters para la clase Libro
    
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public void setAnioPublicacion(int anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }

    public void setEstadoLibro(EstadoLibro estadoLibro) {
        this.estadoLibro = estadoLibro;
    }

    public void setVecesPrestado(int vecesPrestado) {
        this.vecesPrestado = vecesPrestado;
    }
}



//enum para el genero del libro

enum Genero {
    FICCION,
    NO_FICCION,
    MISTERIO,
    CIENCIA,
    HISTORIA,
    BIOGRAFIA,
    FANTASIA
}

//enum para el estado del libro

enum EstadoLibro {
    DISPONIBLE,
    PRESTADO,
    DETERIORADO,
    PERDIDO
}





//clase Prestamo y sus atributos

public class Prestamo {
    private int idPrestamo;
    private Socio socio;
    private Libro libro;
    private String fechaPrestamos;
    private String fechaDevolucionEstimada;
    private String fechaDevolucionReal;
    private EstadoPrestamo estadoPrestamo;
    private double multaGeneradaEstePrestamo;



    //getters para la clase prestamo

    public int getIdPrestamo() {
        return idPrestamo;
    }

    public Socio getSocio() {
        return socio;
    }

    public Libro getLibro() {
        return libro;
    }

    public String getFechaPrestamos() {
        return fechaPrestamos;
    }

    public String getFechaDevolucionEstimada() {
        return fechaDevolucionEstimada;
    }

    public String getFechaDevolucionReal() {
        return fechaDevolucionReal;
    }

    public EstadoPrestamo getEstadoPrestamo() {
        return estadoPrestamo;
    }

    public double getMultaGeneradaEstePrestamo() {
        return multaGeneradaEstePrestamo;
    }

    
    
    //setters para la clase prestamo
    
    public void setIdPrestamo(int idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    public void setSocio(Socio socio) {
        this.socio = socio;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public void setFechaPrestamos(String fechaPrestamos) {
        this.fechaPrestamos = fechaPrestamos;
    }

    public void setFechaDevolucionEstimada(String fechaDevolucionEstimada) {
        this.fechaDevolucionEstimada = fechaDevolucionEstimada;
    }

    public void setFechaDevolucionReal(String fechaDevolucionReal) {
        this.fechaDevolucionReal = fechaDevolucionReal;
    }

    public void setEstadoPrestamo(EstadoPrestamo estadoPrestamo) {
        this.estadoPrestamo = estadoPrestamo;
    }

    public void setMultaGeneradaEstePrestamo(double multaGeneradaEstePrestamo) {
        this.multaGeneradaEstePrestamo = multaGeneradaEstePrestamo;
    }
}

//enum para el estado del prestamo

enum EstadoPrestamo {
    ACTIVO,
    FINALIZADO,
    ATRASADO
}
    }
    
}
